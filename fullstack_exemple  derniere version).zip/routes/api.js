const express = require('express')
const {Login, SignUp, AllUsers} = require("../controllers/user-controller");

const router = express.Router();

router.post('/login', Login)
router.post('/signup',SignUp)
router.get('/users',AllUsers)
module.exports=router

